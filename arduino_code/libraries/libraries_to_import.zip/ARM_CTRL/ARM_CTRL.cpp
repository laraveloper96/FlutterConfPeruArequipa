#include "ARM_CTRL.h"
#include <ESP32Servo.h>

//int ARM_CTRL::val = 0;
//int ARM_CTRL::Chassis_Silde_Angle;
//int ARM_CTRL::Shoulder_Silde_Angle;
//int ARM_CTRL::Elbow_Silde_Angle;
//int ARM_CTRL::Claws_Silde_Angle;
//
//int ARM_CTRL::PTP_X;
//int ARM_CTRL::PTP_Y;
//int ARM_CTRL::PTP_Z;
//
//int ARM_CTRL::stateCount1 = 0;
//int ARM_CTRL::stateCount2 = 0;
//int ARM_CTRL::stateCount3 = 0;
//int ARM_CTRL::stateCount4 = 0;
//int ARM_CTRL::stateCount5 = 0;
//int ARM_CTRL::stateCount6 = 0;
//
//int ARM_CTRL::mode = 1;

// ********************************
// ***** ARM OBJECT SERVOS ********
// ********************************
Servo GRIPPER_SERVO;
Servo WRIST_PITCH_SERVO;
Servo WRIST_ROLL_SERVO;
Servo ELBOW_SERVO;
Servo SHOULDER_SERVO;
Servo WAIST_SERVO;

ARM_CTRL::ARM_CTRL()
{

}

void ARM_CTRL::ARM_init(int s1, int s2, int s3, int s4, int s5, int s6) {
    Serial.println("[callback] ARM_init");
  GRIPPER_SERVO.attach(s1); // send servo to its initial position
  WRIST_PITCH_SERVO.attach(s2);
  WRIST_ROLL_SERVO.attach(s3);
  ELBOW_SERVO.attach(s4);
  SHOULDER_SERVO.attach(s5);
  WAIST_SERVO.attach(s6);
  delay(TIME_BETWEEN_SERVO);
}

void ARM_CTRL::setupInitPosition(){
  Serial.println("[callback] ARM_initPosition");
  WAIST_SERVO.write(waist_angle);// send servo to its initial position
  delay(TIME_BETWEEN_SERVO);
  SHOULDER_SERVO.write(shoulder_angle);// send servo to its initial position
  delay(TIME_BETWEEN_SERVO);
  ELBOW_SERVO.write(elbow_angle);// send servo to its initial position
  delay(TIME_BETWEEN_SERVO);
  WRIST_ROLL_SERVO.write(wrist_roll_angle);// send servo to its initial position
  delay(TIME_BETWEEN_SERVO);
  WRIST_PITCH_SERVO.write(wrist_pitch_angle);// send servo to its initial position
  GRIPPER_SERVO.write(gripper_angle); // send servo to its initial position    
}
//
//void ARM_CTRL::moveServo(Servo& servo, int target){
//
//}

void ARM_CTRL::moveWaist(int waist_angle){
    // Checks if the target position is within the valid range (adjust based on your servo)
    targetAngle = waist_angle;
    if (waist_angle > 180) { //limit the angle when turn right
      targetAngle = 180;
    }
    if (waist_angle < 0) { // limit the angle when turn left
      targetAngle = 0;
    }
  
    float s = speed;
    // Map the position data to the PWM range of the steering gear control
    int pwmValue1 = map(targetAngle, PWMRES_Min, PWMRES_Max, SERVOMIN, SERVOMAX);
    // Get the PWM value of the current steering gear
    int currentPwm1 = WAIST_SERVO.readMicroseconds();
    if(pwmValue1 != currentPwm1){
      //Gradually adjust the PWM value of the steering gear to the target value
      for (int j = 0; j < speed; j++) {
        int newPwm1 = currentPwm1 + (pwmValue1 - currentPwm1) * (j / s);
        // Set the PWM value of the steering gear
        WAIST_SERVO.writeMicroseconds(newPwm1);
        delay(speed);
      }   
    }
}

void ARM_CTRL::moveShoulder(int shoulder_angle){
    // Checks if the target position is within the valid range (adjust based on your servo)
    targetAngle = shoulder_angle;
    if (shoulder_angle > 180) { //limit the angle when turn right
      targetAngle = 180;
    }
    if (shoulder_angle < 0) { // limit the angle when turn left
      targetAngle = 0;
    }
  
    float s = speed;
    // Map the position data to the PWM range of the steering gear control
    int pwmValue1 = map(targetAngle, PWMRES_Min, PWMRES_Max, SERVOMIN, SERVOMAX);
    // Get the PWM value of the current steering gear
    int currentPwm1 = SHOULDER_SERVO.readMicroseconds();
    if(pwmValue1 != currentPwm1){
      //Gradually adjust the PWM value of the steering gear to the target value
      for (int j = 0; j < speed; j++) {
        int newPwm1 = currentPwm1 + (pwmValue1 - currentPwm1) * (j / s);
        // Set the PWM value of the steering gear
        SHOULDER_SERVO.writeMicroseconds(newPwm1);
        delay(speed);
      }
    }
}

void ARM_CTRL::moveElbow(int elbow_angle){
    // Checks if the target position is within the valid range (adjust based on your servo)
    targetAngle = elbow_angle;
    if (elbow_angle > 180) { //limit the angle when turn right
      targetAngle = 180;
    }
    if (elbow_angle < 0) { // limit the angle when turn left
      targetAngle = 0;
    }
  
    float s = speed;
    // Map the position data to the PWM range of the steering gear control
    int pwmValue1 = map(targetAngle, PWMRES_Min, PWMRES_Max, SERVOMIN, SERVOMAX);
    // Get the PWM value of the current steering gear
    int currentPwm1 = ELBOW_SERVO.readMicroseconds();
    if(pwmValue1 != currentPwm1){
      //Gradually adjust the PWM value of the steering gear to the target value
      for (int j = 0; j < speed; j++) {
        int newPwm1 = currentPwm1 + (pwmValue1 - currentPwm1) * (j / s);
        // Set the PWM value of the steering gear
        ELBOW_SERVO.writeMicroseconds(newPwm1);
        delay(speed);
      }
    }
}

void ARM_CTRL::moveWristRoll(int wrist_roll_angle){
    // Checks if the target position is within the valid range (adjust based on your servo)
    targetAngle = wrist_roll_angle;
    if (wrist_roll_angle > 180) { //limit the angle when turn right
      targetAngle = 180;
    }
    if (wrist_roll_angle < 0) { // limit the angle when turn left
      targetAngle = 0;
    }
  
    float s = speed;
    // Map the position data to the PWM range of the steering gear control
    int pwmValue1 = map(targetAngle, PWMRES_Min, PWMRES_Max, SERVOMIN, SERVOMAX);
    // Get the PWM value of the current steering gear
    int currentPwm1 = WRIST_ROLL_SERVO.readMicroseconds();
    if(pwmValue1 != currentPwm1){
      //Gradually adjust the PWM value of the steering gear to the target value
      for (int j = 0; j < speed; j++) {
        int newPwm1 = currentPwm1 + (pwmValue1 - currentPwm1) * (j / s);
        // Set the PWM value of the steering gear
        WRIST_ROLL_SERVO.writeMicroseconds(newPwm1);
        delay(speed);
      }
    }
}

void ARM_CTRL::moveWristPitch(int wrist_pitch_angle){
    // Checks if the target position is within the valid range (adjust based on your servo)
    targetAngle = wrist_pitch_angle;
    if (wrist_pitch_angle > 180) { //limit the angle when turn right
      targetAngle = 180;
    }
    if (wrist_pitch_angle < 0) { // limit the angle when turn left
      targetAngle = 0;
    }
  
    float s = speed;
    // Map the position data to the PWM range of the steering gear control
    int pwmValue1 = map(targetAngle, PWMRES_Min, PWMRES_Max, SERVOMIN, SERVOMAX);
    // Get the PWM value of the current steering gear
    int currentPwm1 = WRIST_PITCH_SERVO.readMicroseconds();
    if(pwmValue1 != currentPwm1){
      //Gradually adjust the PWM value of the steering gear to the target value
      for (int j = 0; j < speed; j++) {
        int newPwm1 = currentPwm1 + (pwmValue1 - currentPwm1) * (j / s);
        // Set the PWM value of the steering gear
        WRIST_PITCH_SERVO.writeMicroseconds(newPwm1);
        delay(speed);
      }
    }
}

void ARM_CTRL::moveGripper(int gripper_angle){
    // Checks if the target position is within the valid range (adjust based on your servo)
    targetAngle = gripper_angle;
    if (gripper_angle > 180) { //limit the angle when turn right
      targetAngle = 180;
    }
    if (gripper_angle < 0) { // limit the angle when turn left
      targetAngle = 0;
    }
  
    float s = speed;
    // Map the position data to the PWM range of the steering gear control
    int pwmValue1 = map(targetAngle, PWMRES_Min, PWMRES_Max, SERVOMIN, SERVOMAX);
    // Get the PWM value of the current steering gear
    int currentPwm1 = GRIPPER_SERVO.readMicroseconds();
    if(pwmValue1 != currentPwm1){
      //Gradually adjust the PWM value of the steering gear to the target value
      for (int j = 0; j < speed; j++) {
        int newPwm1 = currentPwm1 + (pwmValue1 - currentPwm1) * (j / s);
        // Set the PWM value of the steering gear
        GRIPPER_SERVO.writeMicroseconds(newPwm1);
        delay(speed);
      }
    }
}


void ARM_CTRL::setVelocity(int speeds){
  if (speeds > 100){
    speeds = 100;
  } else if (speeds < 0){
    speeds = 1;
  }
  speed = 1000 / speeds;
}
