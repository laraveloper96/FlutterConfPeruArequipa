#ifndef ARM_CTRL_H
#define ARM_CTRL_H

#include <Arduino.h>
#include <ESP32Servo.h>

struct ServoState {
  int pos1;
  int pos2;
  int pos3;
  int pos4;
};

class ARM_CTRL 
{

public:
  

  ARM_CTRL();

  static int val;
  static int Chassis_Silde_Angle;
  static int Shoulder_Silde_Angle;
  static int Elbow_Silde_Angle;
  static int Claws_Silde_Angle;

  static int PTP_X;
  static int PTP_Y;
  static int PTP_Z;

  static int mode;

  static int stateCount1;
  static int stateCount2;
  static int stateCount3;
  static int stateCount4;
  static int stateCount5;
  static int stateCount6;
  
// ********************************
// ************* METHODS **********
// ********************************
  void ARM_init(int s1, int s2, int s3, int s4, int s5, int s6);
  void setupInitPosition();
  void moveWaist(int waist_angle);
  void moveShoulder(int shoulder_angle);
  void moveElbow(int elbow_angle);
  void moveWristRoll(int wrist_roll_angle);
  void moveWristPitch(int wrist_pitch_angle);
  void moveGripper(int gripper_angle);
  void setVelocity(int speeds);

  void Speed(int speeds);

  void PtpCmd (float x, float y, float z);

  void Button_saveState();
  void Button_executeStates();
  void Button_clearSavedStates();

  
// ********************************
// *********** CONSTANTS **********
// ********************************
  const int PWMRES_Min = 0; // PWM Resolution 0
  const int PWMRES_Max = 180; // PWM Resolution 180
  const int SERVOMIN = 400; // 400
  const int SERVOMAX = 2400; // 2400
  const int TIME_BETWEEN_SERVO=300;
  
// ********************************
// ******* GLOBAL VARIABLES  ******
// ********************************
  int speed = 30;
  int targetAngle = 90;
  int waist_angle = 90, shoulder_angle = 90, elbow_angle = 90, wrist_roll_angle = 90, wrist_pitch_angle = 90, gripper_angle = 90;   // define the variable of 6 servo angle,and assign the initial value (that is the boot posture
  
  //angle value)
  int left_X;       // define the right X pin to 32
  int left_Y;       // define the right Y pin to 33
  int left_key;     // define the right key pin to 34
  int right_X;      // define the left X pin to 35
  int right_Y;      // define the left X pin to 36
  int right_key;    //define the left key pin to 39
  int JoyX1 = 0, JoyY1 = 0, JoyZ1 = 0;  // define the variable, used to save the joystick value it read.
  int JoyX2 = 0, JoyY2 = 0, JoyZ2 = 0;
  
  unsigned long lastMovementTime = 0;
  const unsigned long printDelay = 3000; // 3 seconds

  // Define arm length (in inches) and base position
  const float arm1_length = 8;  // Length of arm 1
  const float arm2_length = 7;  // Length of arm 2 
  const float arm3_length = 12;  // Length of arm 3

  float limit_z;
  float servo_angle1,servo_angle2,servo_angle3,servo_angle4;

  int number = 10;//Record the number of actions
  bool leftKeyPressed = false;
  bool rightKeyPressed = false;
  bool longPressHandled = false;
  unsigned long leftKeyPressStartTime = 0; // Record the start time of the left button press
  const unsigned long longPressThreshold = 3000; // Define the time threshold for a long press in milliseconds
  int maxStates = 20;              // 去除 const 修饰
  int stateCount = 0;
  // int stateCount1 = 0;
  // int stateCount2 = 0;
  // int stateCount3 = 0;
  // int stateCount4 = 0;
  // int stateCount5 = 0;
  // int stateCount6 = 0;
  int currentState1 = 0;
  int currentState2 = 0;
  int currentState3 = 0;
  int currentState4 = 0;
  int currentState5 = 0;
  int currentState6 = 0;
  int currentState = 0;
  
  ServoState states[20];
  ServoState states1[20];
  ServoState states2[20];
  ServoState states3[20];
  ServoState states4[20];
  ServoState states5[20];
  ServoState states6[20];

  float chassis_pos = 90;
  float right_poss;
  float left_poss;

  // int mode = 1;
  int chassis_pos2 = 0;
  int WuchaPos = 0;
  
  bool run_state = false;

  

private:
  
};

#endif // ARM_CTRL_H
