#ifndef MQTT_ROBOT_H
#define MQTT_ROBOT_H

#include <Arduino.h>
#include <WiFi.h>
#include <PubSubClient.h>

#if defined(ESP8266) || defined(ESP32)
#include <functional>
#define MQTT_CALLBACK_DEFAULT std::function<void(char*, uint8_t*, unsigned int)> callback
#else
#define MQTT_CALLBACK_DEFAULT void (*callback)(char*, uint8_t*, unsigned int)
#endif

#if defined(ESP8266) || defined(ESP32)
#include <functional>
#define MQTT_CALLBACK_RECONNECT std::function<void()> callbackReconnect
#else
#define MQTT_CALLBACK_RECONNECT void (*callbackReconnect)()
#endif

class MQTT_ROBOT
{

public:
  
  MQTT_ROBOT();

  // ********************************
  // ************* METHODS **********
  // ********************************
  void begin();
  boolean loop(MQTT_CALLBACK_RECONNECT);
  boolean connected();
  boolean connect(const char* id, const char* user, const char* pass);
  boolean publish(const char* topic, const char* payload);
  boolean subscribe(const char* topic);
  int state();
  void MQTT_setupWifi(const char* ssid,const char* pass);
  String getMacAddress();
  void setServer(const char* mqttServer,const int mqttPort);
  void setCallback(MQTT_CALLBACK_DEFAULT);
  void setClient(Client& client);
  
  WiFiClient espClient;
  PubSubClient mqttClient;
  // String clientName = "";
  // String clientId = "";
  String macEsp32;    // the MAC address of your Wifi shield
  //// ********************************
  //// *********** MQTT CONFIG ********
  //// ********************************
  // char *mqttServer = "192.168.18.75";
  // int mqttPort = 1883;
  char *mqttUser = "";
  char *mqttPass = "";
  const char *rootTopicSubscribe = "robot/movement";
  const char *rootTopicPublish = "human/message";
  const char *rootRegisterTopicPublish = "human/register/robot";

private:
  // void reconnect();
  MQTT_CALLBACK_DEFAULT;
  MQTT_CALLBACK_RECONNECT;
};

#endif // MQTT_ROBOT_H  
