#include "MQTT_ROBOT.h"
// #include <ArduinoJson.h>

// ********************************
// *********** MQTT CONFIG ********
// ********************************

//const char *mqttServer = "192.168.18.75";
//const int mqttPort = 1883;
//const char *mqttUser = "";
//const char *mqttPass = "";
//const char *rootTopicSubscribe = "robot/movement";
//const char *rootTopicPublish = "human/message";
//const char *rootRegisterTopicPublish = "human/register/robot";

// Create the JSON object
// DynamicJsonDocument doc(1024); // JSON object size (adjust according to your needs)

MQTT_ROBOT::MQTT_ROBOT()
{

}

void MQTT_ROBOT::MQTT_setupWifi(const char* ssid,const  char* pass){
  Serial.println("[callback] setupWifi");
  delay(10);
  Serial.println();
  Serial.print("Conecting a ssid: ");
  Serial.println(ssid);
  WiFi.begin(ssid, pass);
  while (WiFi.status() != WL_CONNECTED){
    delay(1000);
    Serial.print(".");
  }
  Serial.println("");
  Serial.println("Conected to red WiFi!");
  Serial.println("Address IP: ");
  Serial.println(WiFi.localIP());
}
void MQTT_ROBOT::setClient(Client& client){
  mqttClient.setClient(client);
}

void MQTT_ROBOT::setServer(const char* mqttServer,const int mqttPort){
  mqttClient.setServer(mqttServer, mqttPort);
}

void MQTT_ROBOT::setCallback(MQTT_CALLBACK_DEFAULT) {
    mqttClient.setCallback(callback);
}

String MQTT_ROBOT::getMacAddress(){
  Serial.print("ESP32 MAC Address: ");
  byte mac[6];
  WiFi.macAddress(mac);
  char macStr[18]; // Espacio suficiente para la dirección MAC en formato "XX:XX:XX:XX:XX:XX"
  sprintf(macStr, "%02X:%02X:%02X:%02X:%02X:%02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  return String(macStr);
}

boolean MQTT_ROBOT::connected(){
  return mqttClient.connected();
}

boolean MQTT_ROBOT::connect(const char* id, const char* user, const char* pass){
  return mqttClient.connect(id, user, pass);
}

boolean MQTT_ROBOT::publish(const char* topic, const char* payload) {
  return mqttClient.publish(topic, payload);
}

boolean MQTT_ROBOT::subscribe(const char* topic) {
  return mqttClient.subscribe(topic);
}

boolean MQTT_ROBOT::loop(MQTT_CALLBACK_RECONNECT) {
  if (!mqttClient.connected()) {
    callbackReconnect();
  }

  mqttClient.loop();

  return true;
}

int MQTT_ROBOT::state(){
  return mqttClient.state();
}
